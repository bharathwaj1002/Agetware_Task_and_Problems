# views.py
from django.shortcuts import render, get_object_or_404
from .models import Customer, Loan, Payment
from django.http import JsonResponse

def lend_loan(request, customer_id, loan_amount, loan_period, interest_rate):
    customer = get_object_or_404(Customer, id=customer_id)
    
    # Convert loan_amount and interest_rate from str to float
    loan_amount = float(loan_amount)
    interest_rate = float(interest_rate)

    loan = Loan.objects.create(
        customer=customer,
        loan_amount=loan_amount,
        loan_period=loan_period,
        interest_rate=interest_rate
    )
    return JsonResponse({
        'loan_id': loan.id,
        'total_amount': loan.total_amount,
        'monthly_emi': loan.monthly_emi
    })

def make_payment(request, loan_id, payment_amount, payment_type):
    loan = get_object_or_404(Loan, id=loan_id)
    
    # Convert payment_amount from str to float
    payment_amount = float(payment_amount)

    payment = Payment.objects.create(
        loan=loan,
        payment_amount=payment_amount,
        payment_type=payment_type
    )
    return JsonResponse({
        'loan_id': loan.id,
        'balance_amount': loan.balance_amount,
        'emi_left': loan.emi_left
    })

def ledger(request, loan_id):
    loan = get_object_or_404(Loan, id=loan_id)
    payments = Payment.objects.filter(loan=loan).order_by('payment_date')
    transactions = [{
        'payment_date': payment.payment_date,
        'payment_amount': payment.payment_amount,
        'payment_type': payment.payment_type
    } for payment in payments]

    return JsonResponse({
        'loan_id': loan.id,
        'total_amount': loan.total_amount,
        'monthly_emi': loan.monthly_emi,
        'emi_left': loan.emi_left,
        'balance_amount': loan.balance_amount,
        'transactions': transactions
    })


def account_overview(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    loans = Loan.objects.filter(customer=customer)
    overview = [{
        'loan_id': loan.id,
        'loan_amount': loan.loan_amount,
        'total_amount': loan.total_amount,
        'monthly_emi': loan.monthly_emi,
        'interest_rate': loan.interest_rate,
        'balance_amount': loan.balance_amount,
        'emi_left': loan.emi_left
    } for loan in loans]

    return JsonResponse({'customer_id': customer.id, 'loans': overview})