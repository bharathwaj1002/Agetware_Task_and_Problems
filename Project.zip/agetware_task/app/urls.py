# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('lend/<int:customer_id>/<str:loan_amount>/<int:loan_period>/<str:interest_rate>/', views.lend_loan, name='lend_loan'),
    path('payment/<int:loan_id>/<str:payment_amount>/<str:payment_type>/', views.make_payment, name='make_payment'),
    path('ledger/<int:loan_id>/', views.ledger, name='ledger'),
    path('overview/<int:customer_id>/', views.account_overview, name='account_overview'),
]