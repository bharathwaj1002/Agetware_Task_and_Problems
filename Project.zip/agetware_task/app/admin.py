# admin.py
from django.contrib import admin
from .models import Customer, Loan, Payment

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'phone_number', 'is_verified')

@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ('customer', 'loan_amount', 'interest_rate', 'total_amount', 'balance_amount', 'emi_left')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('loan', 'payment_amount', 'payment_type', 'payment_date')