# models.py
import decimal
from django.db import models
from django.contrib.auth.models import User

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    # Basic Information
    full_name = models.CharField(max_length=255)
    email = models.EmailField(max_length=254, unique=True)
    phone_number = models.CharField(max_length=15)
    
    # Address Information
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=10)
    
    # KYC Information
    kyc_document_type = models.CharField(
        max_length=50,
        choices=[
            ('PAN', 'PAN Card'),
            ('Aadhar', 'Aadhar Card'),
            ('Passport', 'Passport')
        ]
    )
    kyc_document_number = models.CharField(max_length=50, unique=True)
    
    # Status
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return self.full_name


class Loan(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    loan_amount = models.DecimalField(max_digits=12, decimal_places=2)
    loan_period = models.IntegerField(help_text="Loan period in years")
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, help_text="Interest rate in %")
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    monthly_emi = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    balance_amount = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    emi_left = models.IntegerField(blank=True, null=True)

    def save(self, *args, **kwargs):
        # Calculate interest and total amount
        interest = (self.loan_amount * self.loan_period * self.interest_rate) / 100
        self.total_amount = self.loan_amount + interest
        self.monthly_emi = self.total_amount / (self.loan_period * 12)
        self.balance_amount = self.total_amount
        self.emi_left = self.loan_period * 12
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Loan for {self.customer.full_name} - {self.loan_amount}"


class Payment(models.Model):
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE)
    payment_date = models.DateTimeField(auto_now_add=True)
    payment_amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_type = models.CharField(max_length=20, choices=[('EMI', 'EMI'), ('Lump Sum', 'Lump Sum')])

    def save(self, *args, **kwargs):
        if self.payment_type == 'EMI':
            self.loan.balance_amount -= self.loan.monthly_emi
            self.loan.emi_left -= 1
        else:
            self.loan.balance_amount -= decimal.Decimal(self.payment_amount)
            emi_reduction = int(decimal.Decimal(self.payment_amount) / self.loan.monthly_emi)
            self.loan.emi_left -= emi_reduction
        self.loan.save()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Payment of {self.payment_amount} for Loan {self.loan.id}"
