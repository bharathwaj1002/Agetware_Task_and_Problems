def minimize_loss(prices):
    min_loss = float('inf')
    buy_year = sell_year = -1
    
    for i in range(len(prices)):
        for j in range(i + 1, len(prices)):
            if prices[j] < prices[i]:
                loss = prices[i] - prices[j]
                if loss < min_loss:
                    min_loss = loss
                    buy_year = i + 1
                    sell_year = j + 1
    
    if buy_year == -1 or sell_year == -1:
        return "No loss can be incurred."
    
    return f"Buy in year {buy_year}, Sell in year {sell_year}, Loss: {min_loss}"

prices = list(map(int, input().split()))
result = minimize_loss(prices)
print(result)