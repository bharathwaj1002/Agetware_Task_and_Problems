import json


def combine_elements(list1, list2):
    combined_list = sorted(list1 + list2, key=lambda x: x["positions"][0])
    result = []
    for elem in combined_list:
        if not result:
            result.append(elem)
        else:
            last_elem = result[-1]
            last_left, last_right = last_elem["positions"]
            curr_left, curr_right = elem["positions"]
            last_length = last_right - last_left
            curr_length = curr_right - curr_left
            overlap = min(last_right, curr_right) - max(last_left, curr_left)
            if overlap > 0 and (overlap >= last_length / 2 or overlap >= curr_length / 2):
                last_elem["values"].extend(elem["values"])
            else:
                result.append(elem)
    return result


def get_input_list(prompt):
    while True:
        try:
            user_input = input(prompt)
            return json.loads(user_input)
        except json.JSONDecodeError:
            print("Invalid input format. Please enter a valid JSON-like structure.")


list1 = get_input_list("Enter list1 in JSON format: ")

list2 = get_input_list("Enter list1 in JSON format: ")



combined_result = combine_elements(list1, list2)
print(combined_result)