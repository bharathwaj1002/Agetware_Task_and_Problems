def format_indian_currency(number):
    number_str = "{:.4f}".format(number)
    if '.' in number_str:
        integer_part, decimal_part = number_str.split('.')
    else:
        integer_part = number_str
        decimal_part = ''
    reversed_integer = integer_part[::-1]
    formatted_reversed = reversed_integer[:3] + ''.join(
        [',' + reversed_integer[i:i+2] for i in range(3, len(reversed_integer), 2)]
    )
    formatted_integer = formatted_reversed[::-1]
    if decimal_part:
        return formatted_integer + '.' + decimal_part
    else:
        return formatted_integer

number = float(input())
formatted_number = format_indian_currency(number)
print(formatted_number)
