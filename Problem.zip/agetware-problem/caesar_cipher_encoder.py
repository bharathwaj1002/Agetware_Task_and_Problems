def caesar_cipher_encode(message, shift):
    encoded_message = ""
    for char in message:
        if char.isalpha():
            shift_mod = shift % 26
            if char.isupper():
                encoded_message += chr((ord(char) - 65 + shift_mod) % 26 + 65)
            else:
                encoded_message += chr((ord(char) - 97 + shift_mod) % 26 + 97)
        else:
            encoded_message += char
    return encoded_message

def caesar_cipher_decode(message, shift):
    decoded_message = ""
    for char in message:
        if char.isalpha():
            shift_mod = shift % 26
            if char.isupper():
                decoded_message += chr((ord(char) - 65 - shift_mod) % 26 + 65)
            else:
                decoded_message += chr((ord(char) - 97 - shift_mod) % 26 + 97)
        else:
            decoded_message += char
    return decoded_message

message = input()
shift = int(input())

encoded_message = caesar_cipher_encode(message, shift)
print(f"Encoded: {encoded_message}")

decoded_message = caesar_cipher_decode(encoded_message, shift)
print(f"Decoded: {decoded_message}")
